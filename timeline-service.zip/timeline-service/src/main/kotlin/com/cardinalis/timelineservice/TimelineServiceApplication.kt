package com.cardinalis.timelineservice

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class TimelineServiceApplication

fun main(args: Array<String>) {
	runApplication<TimelineServiceApplication>(*args)
}
